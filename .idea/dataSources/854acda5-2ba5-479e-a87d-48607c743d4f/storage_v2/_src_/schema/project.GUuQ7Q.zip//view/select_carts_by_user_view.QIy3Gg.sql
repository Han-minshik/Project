create definer = root@localhost view select_carts_by_user_view as
select `c`.`user_id` AS `user_id`,
       `c`.`no`      AS `cart_no`,
       `b`.`isbn`    AS `book_isbn`,
       `b`.`title`   AS `book_title`,
       `b`.`price`   AS `book_price`,
       `b`.`image`   AS `book_image`
from (`project`.`cart` `c` join `project`.`book` `b` on ((`c`.`book_isbn` = `b`.`isbn`)));

